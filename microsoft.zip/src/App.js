import Form from "./components/Form";
import "./styles.css";

export default function App() {
  return (
    <div className="">
      <Form />
    </div>
  );
}
