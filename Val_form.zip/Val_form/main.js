function validation_form(){
    const username= document.forms.reg.username.value;
    const email=document.forms.reg.email.value;
    const pwd=document.forms.reg.pwd.value;
    const ph_no= document.forms.reg.ph_no.value;
    const confirm_pwd = document.forms.reg.confirm_pwd.value;

    
    const re_username=/^[a-zA-Z0-9]{3,20}$/
    const re_email=/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/
    const re_pwd=/^(?=.*\d)(?=.*[!@#$%^&*])(?=.*[a-z])(?=.*[A-Z]).{8,}$/
    const re_ph= /^\+91 \d{10}$/;

    if  (!re_username.test(username)){
        alert("Invalid Username. \nShould contain only alphanumeric characters (letters and numbers) and be between 3 and 20 characters long.")
    } 

    if  (!re_email.test(email)){
        alert('Invalid Email.\n Should be in the format: name@example.com')    
    } 

    if  (!re_pwd.test(pwd)){
        alert('Invalid Password.\nShould be at least 8 characters long, containing at least one uppercase letter, one lowercase letter, one number, and one special character ')    
    } 

     if  (!re_ph.test(ph_no)){
        alert('Invalid Mobile Number.\nShould be in the format: +91 1234567890.')    
    }

    if (confirm_pwd!=pwd){
        alert("Confirm Password Doesn\'t match");
    }
    else{

        alert("All Credentials are Valid");
        return false;
    } 

}