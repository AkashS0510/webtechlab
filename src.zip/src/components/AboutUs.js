import React from 'react';
import NvImage from '../nv.png';
function AboutUs({ heading , isDarkMode}) {

  const pageClass = isDarkMode ? 'dark-mode-page' : 'light-mode-page';
  return (
    <div className={pageClass}>
      <h1 className="center-heading">
      {heading}
      </h1>
      <p className="center-paragraph">
        
        You’ll solve some of the world’s hardest problems and discover never-before-seen ways to improve the quality of life for people everywhere. From healthcare to robots. Self-driving cars to blockbuster movies. And a growing list of new opportunities every single day. Watch this video for a glimpse at why NVIDIA is like no place you've ever worked.
        {/* <Nv width="100px" height="auto"/> */}
      </p>
      <img src={NvImage} alt="NVIDIA Image" />

    
    </div>
  );
}

export default AboutUs;