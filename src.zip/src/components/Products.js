import React from 'react';

function Products({ heading , isDarkMode}) {
  const pageClass = isDarkMode ? 'dark-mode-page' : 'light-mode-page';
  const tableClass = isDarkMode ? 'dark-mode-table' : 'light-mode-table';
  const hardwareList = [
    ["GeForce Graphics Cards", "Gaming Laptops", "G-SYNC Monitors"
    ,"Laptops and Workstations", "Laptops", "NVIDIA RTX in Desktop Workstations", "NVIDIA RTX in Professional Laptops", "NVIDIA RTX-Powered AI Workstations"]
  ];

  const softwareList = [
    ['AI Inference - Triton', 'Automotive - DRIVE', 'Cloud-AI Video Streaming - Maxine', 'Computational Lithography - cuLitho', 'Cybersecurity - Morpheus', 'Data Analytics - RAPIDS']
  ];

  return (
    <div className={pageClass}>
      <h1 className="center-heading">{heading}</h1>

      <div className="product-section">
        <h2 className="center-heading">Hardware</h2>
        <table className={tableClass}>
          <thead>
            <tr>
              <th>Products</th>
            </tr>
          </thead>
          <tbody>
            {hardwareList[0].map((product, productIndex) => (
              <tr key={productIndex}>
                <td>{product}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="product-section">
        <h2 className="center-heading">Software</h2>
        <table className={tableClass}>
          <thead>
            <tr>
              <th>Products</th>
            </tr>
          </thead>
          <tbody>
            {softwareList[0].map((product, productIndex) => (
              <tr key={productIndex}>
                <td>{product}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default Products;
