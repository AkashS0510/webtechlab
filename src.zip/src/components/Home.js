import React from 'react';
import home from '../home.png';
function Home({ heading , isDarkMode}) {
  const pageClass = isDarkMode ? 'dark-mode-page' : 'light-mode-page';
  return (
    <div className={pageClass}>
      <h1 className="center-heading">{heading}</h1>
      <img src={home} alt="Home Image" width='100%' height='auto'/>
    </div>
  );
}

export default Home;
