import React , { useState }from 'react';
import { Routes, Route, Link } from 'react-router-dom';
import Home from './components/Home';
import AboutUs from './components/AboutUs';
import Products from './components/Products';
import './App.css';
import { ReactComponent as NvidiaLogo } from './nvidia.svg';


import { Navbar, Nav,Button } from 'react-bootstrap';

function App() {

  const [isDarkMode, setIsDarkMode] = useState(false);

  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
    document.body.classList.toggle('dark-mode'); // Apply a CSS class for dark mode
  };





  return (
    <div classname="Container">
    <Navbar bg={isDarkMode ? 'dark' : 'light'} variant={isDarkMode ? 'dark' : 'light'}>
      <Navbar.Brand as={Link} to="/">
            <h1 className="nav-logo">
            <NvidiaLogo width="100px" height="auto"/></h1>
      </Navbar.Brand>
      <Nav className="mr-auto">
        <Nav.Link as={Link} to="/">Home</Nav.Link>
        <Nav.Link as={Link} to="/about">About</Nav.Link>
        <Nav.Link as={Link} to="/products">products</Nav.Link>
      </Nav>
      <Button variant={isDarkMode ? 'light' : 'dark'} onClick={toggleDarkMode}>
        {isDarkMode ? 'Light Mode' : 'Dark Mode'}
      </Button>
    </Navbar>

<Routes>
<Route path="/" element={<Home heading="Welcome To Nvidia" isDarkMode={isDarkMode}/>} />
<Route path="/about" element={<AboutUs heading="Follow Your Passion. Lead a Movement...." isDarkMode={isDarkMode}/>} />
<Route path="/products" element={<Products heading="Products" isDarkMode={isDarkMode}/>} />
</Routes>
</div>
  );
}

export default App;


// function App() {
//   return (
//     <div classname='home'>
//       <div className="navbar">
//       <ul className="nav-links">
//         <li>
//             <Link to="/" className="nav-link">
//             <h1 className="nav-logo">
//             <NvidiaLogo width="100px" height="auto"/></h1>
//             </Link>
//           </li>
//         </ul>
//         <ul className="nav-links">
      
//           <li>
//             <Link to="/" className="nav-link">Home</Link>
//           </li>
//           <li>
//             <Link to="/about" className="nav-link">About Us</Link>
//           </li>
//           <li>
//             <Link to="/products" className="nav-link">Products</Link>
//           </li>
//         </ul>
//       </div>

//       <div className="container">
//         <Routes>
//           <Route path="/" element={<Home />} />
//           <Route path="/about" element={<AboutUs />} />
//           <Route path="/products" element={<Products />} />
//         </Routes>
//       </div>
//     </div>
//   );
// }

// export default App;

/*
  Bonus questions:

  1) NVIDIA has AI and DS roles, in fields including autonomous vehicles, healthcare, and more.
  2) These roles involve developing AI-powered technologies and data-driven solutions.
  3) Their Requirements usually include expertise in machine learning, deep learning, data analysis, and programming.
  4) The future of NVIDIA seems promising with its focus on AI, GPUs, and  technologies like self-driving cars.
  5) AI and DS have the potential to  disrupt sectors by revolutionizing and automating processes and decision-making.
  6) NVIDIA's expertise in AI and DS makes them to successfully utilize these technologies for causing  disruption.
  7) Yes, I would be interested in making a career at this company since NVIDIA offers exciting opportunities in in AI and DS.
 */