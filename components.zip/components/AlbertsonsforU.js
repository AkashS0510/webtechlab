import React from 'react';
// import career from '../career.png';
const AlbertsonsforU = () => {
  return (
    <div>
      <h1 className="center-heading">AlbertsonsforU </h1>
      {/* <img src={career} alt="Career Image" /> */}
    </div>
  );
}

export default AlbertsonsforU;
 