import React from 'react';
// import career from '../career.png';
const Shop = () => {
  return (
    <div>
      <h1 className="center-heading">Shop </h1>
      {/* <img src={career} alt="Career Image" /> */}
    </div>
  );
}

export default Shop;
 