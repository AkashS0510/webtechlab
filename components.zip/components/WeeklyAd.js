import React from 'react';
// import career from '../career.png';
const WeeklyAd = () => {
  return (
    <div>
      <h1 className="center-heading">WeeklyAd </h1>
      {/* <img src={career} alt="Career Image" /> */}
    </div>
  );
}

export default WeeklyAd;
 